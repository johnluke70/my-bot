package com.ubs;

import com.ubs.core.Instrument;
import com.ubs.core.State;
import com.ubs.core.TwoWayPrice;

import static com.ubs.core.State.FIRM;

public final class VwapPriceUpdate implements TwoWayPrice {

    VwapPriceUpdate(Instrument instrument) {
        this(instrument, FIRM, 0.0, 0.0, 0.0, 0.0);
    }

    public VwapPriceUpdate(
            Instrument instrument,
            State state,
            double bidPrice,
            double bidAmount,
            double offerPrice,
            double offerAmount) {

        this.instrument = instrument;
        this.state = state;
        this.bidPrice = ensureValidValue(bidPrice);
        this.bidAmount = bidAmount;
        this.offerPrice = ensureValidValue(offerPrice);
        this.offerAmount = offerAmount;
    }

    private final Instrument instrument;
    private State state;
    private double bidPrice;
    private double bidAmount;
    private double offerPrice;
    private double offerAmount;

    @Override
    public Instrument getInstrument() {
        return instrument;
    }

    @Override
    public State getState() {
        return state;
    }

    @Override
    public double getBidPrice() {
        return bidPrice;
    }

    @Override
    public double getOfferAmount() {
        return offerAmount;
    }

    @Override
    public double getOfferPrice() {
        return offerPrice;
    }

    @Override
    public double getBidAmount() {
        return bidAmount;
    }

    public void setState(State state) {
        this.state = state;
    }

    public void setBidPrice(double bidPrice) {
        this.bidPrice = ensureValidValue(bidPrice);
    }

    public void setOfferPrice(double offerPrice) {
        this.offerPrice = ensureValidValue(offerPrice);
    }

    public void setBidAmount(double bidAmount) {
        this.bidAmount = ensureValidValue(bidAmount);
    }

    public void setOfferAmount(double offerAmount) {
        this.offerAmount = ensureValidValue(offerAmount);
    }

    private double ensureValidValue(double val) {
        if (val < 0)
            throw new IllegalArgumentException("Only positive or zero values are allowed");

        return val;
    }
}
