package com.ubs.core;

public enum State {
    FIRM, INDICATIVE
}