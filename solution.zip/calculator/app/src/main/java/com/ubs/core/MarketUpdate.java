package com.ubs.core;

public interface MarketUpdate {
    Market getMarket();
    TwoWayPrice getTwoWayPrice();
}