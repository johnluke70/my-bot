package com.ubs;

import static java.lang.Math.abs;

public final class Utils {

    public static boolean eq(double a, double b) {
        return abs(a-b) <= EPSILON;
    }

    public static boolean neq(double a, double b) {
        return abs(a-b) > EPSILON;
    }

    private static final double EPSILON = 0.00001;
}
