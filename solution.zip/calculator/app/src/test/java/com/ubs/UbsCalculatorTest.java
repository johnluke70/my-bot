package com.ubs;

import com.ubs.core.Instrument;
import com.ubs.core.Market;
import com.ubs.core.State;
import com.ubs.core.TwoWayPrice;
import org.junit.jupiter.api.Test;

import static com.ubs.Utils.eq;
import static com.ubs.core.Instrument.*;
import static com.ubs.core.Market.*;
import static com.ubs.core.State.FIRM;
import static com.ubs.core.State.INDICATIVE;
import static java.util.Arrays.asList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UbsCalculatorTest {

    @Test
    void given_a_market_update_the_returned_vwap_must_contain_the_correct_instrument_reference() {
        // Given
        UbsCalculator calculator = new UbsCalculator();

        // When
        TwoWayPrice vwapPrice = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(MARKET0, INSTRUMENT0, INDICATIVE, 1.23, 1.27, 10.2, 10.4));

        // Then
        assertEquals(INSTRUMENT0, vwapPrice.getInstrument(), "Instrument type should be correct");
    }

    @Test
    void given_an_empty_aggregator_vawp_initial_values_should_be_correct() {
        // Given
        UbsCalculator calculator = new UbsCalculator();

        // When
        TwoWayPrice vwapPrice = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(MARKET0, INSTRUMENT0, FIRM, 0.0, 0.0, 0.0, 0.0));

        // Then
        assertEquals(0.0, vwapPrice.getBidAmount(), "Bid amount should be correct");
        assertEquals(0.0, vwapPrice.getBidPrice(), "Bid price should be correct");
        assertEquals(0.0, vwapPrice.getOfferAmount(), "Offer amount should be correct");
        assertEquals(0.0, vwapPrice.getOfferPrice(), "Offer price should be correct");
    }

    @Test
    void when_a_single_market_price_update_is_marked_indicative_vwap_should_be_indicative_as_well() {
        // Given
        UbsCalculator calculator = new UbsCalculator();
        // Initialize so that all markets have returned firmed prices on a given instrument
        obtainSingleMarketUpdateFromEveryMarket(calculator, INSTRUMENT0, FIRM);

        // When
        TwoWayPrice vwapPrice = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(MARKET5, INSTRUMENT0, INDICATIVE, 1.0, 1.0, 1.0, 1.0));

        // Then
        assertEquals(INDICATIVE, vwapPrice.getState(), "Vwap should be indicative if one price is indicative");

        // And When
        TwoWayPrice vwapPrice2 = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(MARKET5, INSTRUMENT0, FIRM, 1.0, 1.0, 1.0, 1.0));

        assertEquals(FIRM, vwapPrice2.getState(), "Vwap should be firm when all market updates are firm");
    }

    @Test
    void vwap_prices_should_be_calculated_properly() {
        // Given
        UbsCalculator calculator = new UbsCalculator();

        // When
        TwoWayPrice vwapPrice_0 = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(MARKET0, INSTRUMENT1, FIRM, 1.1, 2.2, 3.3, 4.4));

        // Then
        assertEquals(FIRM, vwapPrice_0.getState(), "vwapPrice_0 should be firm");

        assertEquals(1.1, vwapPrice_0.getBidPrice(), "vwapPrice_0.getBidPrice should be correct");
        assertEquals(2.2, vwapPrice_0.getBidAmount(), "vwapPrice_0.getBidAmount should be correct");
        assertEquals(3.3, vwapPrice_0.getOfferPrice(), "vwapPrice_0.getOfferPrice should be correct");
        assertEquals(4.4, vwapPrice_0.getOfferAmount(), "vwapPrice_0.getOfferAmount should be correct");

        // And When
        TwoWayPrice vwapPrice_1 = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(MARKET1, INSTRUMENT1, FIRM, 1.2, 2.3, 3.4, 4.5));
        // Then
        assertEquals(FIRM, vwapPrice_1.getState(), "vwapPrice_0 should be firm");

        assertTrue(eq(1.15111, vwapPrice_1.getBidPrice()), "vwapPrice_1.getBidPrice should be [(1.1*2.2) + (1.2*2.3)] / (2.2+2.3) -> 1.151111..");
        assertTrue(eq(4.5, vwapPrice_1.getBidAmount()), "vwapPrice_1.getBidAmount should be firm");
        assertTrue(eq(3.35056, vwapPrice_1.getOfferPrice()), "vwapPrice_1.getOfferPrice should be firm [(3.3*4.4) + (3.4*4.5)] / (4.4+4.5)");
        assertTrue(eq(8.9, vwapPrice_1.getOfferAmount()), "vwapPrice_1.getOfferAmount should be firm");
    }

    @Test
    void instrument_vwap_prices_should_not_affect_other_instruments_vwap_prices_for_the_same_provider() {
        // Given
        UbsCalculator calculator = new UbsCalculator();
        final Market marketProvider = MARKET0;

        // When
        TwoWayPrice vwapInstrument_1 = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(marketProvider, INSTRUMENT1, FIRM, 1.0, 2.0, 3.0, 4.0));

        // Then -- Instrument 1 Update
        assertEquals(FIRM, vwapInstrument_1.getState(), "vwapInstrument_1 should be firm");

        assertEquals(1.0, vwapInstrument_1.getBidPrice(), "vwapInstrument_1.getBidPrice should be correct");
        assertEquals(2.0, vwapInstrument_1.getBidAmount(), "vwapInstrument_1.getBidAmount should be correct");
        assertEquals(3.0, vwapInstrument_1.getOfferPrice(), "vwapInstrument_1.getOfferPrice should be correct");
        assertEquals(4.0, vwapInstrument_1.getOfferAmount(), "vwapInstrument_1.getOfferAmount should be correct");

        // Then -- Instrument 15 Update
        TwoWayPrice result_instrument_15 = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(marketProvider, INSTRUMENT15, INDICATIVE, 10.0, 20.0, 30.0, 40.0));

        assertEquals(INDICATIVE, result_instrument_15.getState(), "result_instrument_15 should be indicative");

        assertEquals(10.0, result_instrument_15.getBidPrice(), "result_instrument_15.getBidPrice should be correct");
        assertEquals(20.0, result_instrument_15.getBidAmount(), "result_instrument_15.getBidAmount should be correct");
        assertEquals(30.0, result_instrument_15.getOfferPrice(), "result_instrument_15.getOfferPrice should be correct");
        assertEquals(40.0, result_instrument_15.getOfferAmount(), "result_instrument_15.getOfferAmount should be correct");

        // Then -- Instrument 1 Update Second Time
        TwoWayPrice result_instrument_1b = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(marketProvider, INSTRUMENT1, INDICATIVE, 3.0, 2.0, 5.0, 4.0));

        assertEquals(INDICATIVE, result_instrument_1b.getState(), "result_instrument_1b should be indicative");

        assertEquals(3.0, result_instrument_1b.getBidPrice(), "result_instrument_1b.getBidPrice should be correct");
        assertEquals(2.0, result_instrument_1b.getBidAmount(), "result_instrument_1b.getBidAmount should be correct");
        assertEquals(5.0, result_instrument_1b.getOfferPrice(), "result_instrument_1b.getOfferPrice should be correct");
        assertEquals(4.0, result_instrument_1b.getOfferAmount(), "result_instrument_1b.getOfferAmount should be correct");

        // Then -- Instrument 15 Update Second Time
        TwoWayPrice result_instrument_15_b = calculator.applyMarketUpdate(
                new ProviderMarketUpdate(marketProvider, INSTRUMENT15, FIRM, 15.0, 20.0, 0.0, 0.0));

        assertEquals(FIRM, result_instrument_15_b.getState(), "result_instrument_15_b should be indicative");

        assertEquals(15.0, result_instrument_15_b.getBidPrice(), "result_instrument_15_b.getBidPrice should be correct");
        assertEquals(20.0, result_instrument_15_b.getBidAmount(), "result_instrument_15_b.getBidAmount should be correct");
        assertEquals(0.0, result_instrument_15_b.getOfferPrice(), "result_instrument_15_b.getOfferPrice should be correct");
        assertEquals(0.0, result_instrument_15_b.getOfferAmount(), "result_instrument_15_b.getOfferAmount should be correct");
    }


    void obtainSingleMarketUpdateFromEveryMarket(UbsCalculator calculator, Instrument instrument, State state) {
        asList(Market.values())
                .forEach(market -> calculator.applyMarketUpdate((
                        new ProviderMarketUpdate(market, instrument, state, 1.0, 2.0, 3.0, 4.0))));
    }

}
