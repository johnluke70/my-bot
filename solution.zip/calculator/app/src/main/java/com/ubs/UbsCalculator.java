package com.ubs;

import com.ubs.core.Calculator;
import com.ubs.core.Instrument;
import com.ubs.core.MarketUpdate;
import com.ubs.core.TwoWayPrice;

import java.util.Map;

import static java.util.Arrays.stream;
import static java.util.function.Function.identity;
import static java.util.stream.Collectors.toMap;

public final class UbsCalculator implements Calculator {

    public UbsCalculator() {
        marketValues = stream(Instrument.values()).collect(toMap(identity(), MarketAggregator::new));
    }

    @Override
    public TwoWayPrice applyMarketUpdate(MarketUpdate marketUpdate) {
        return marketValues.get(marketUpdate.getTwoWayPrice().getInstrument()).merge(marketUpdate);
    }

    private final Map<Instrument, MarketAggregator> marketValues;
}
