package com.ubs;

import com.ubs.core.Instrument;
import com.ubs.core.Market;
import com.ubs.core.MarketUpdate;
import com.ubs.core.State;
import org.openjdk.jmh.annotations.*;

import java.util.List;
import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


import static com.ubs.core.State.FIRM;
import static com.ubs.core.State.INDICATIVE;
import static java.lang.System.currentTimeMillis;
import static java.util.concurrent.TimeUnit.MICROSECONDS;
import static java.util.stream.Collectors.toList;
import static org.openjdk.jmh.annotations.Mode.AverageTime;

public class SpeedBench {

    public SpeedBench() {
    }

    @Benchmark
    @Fork(1)
    @Warmup(iterations = 3, time = 7)
    @BenchmarkMode(AverageTime)
    @Measurement(iterations = 10, time = 15, batchSize = 1)
    @OutputTimeUnit(MICROSECONDS)
    public void market_update(TrialState state) {
        state.batch.forEach(state.calculator::applyMarketUpdate);
    }

    @org.openjdk.jmh.annotations.State(Scope.Thread)
    public static class TrialState {

        public TrialState() {
        }

        @Setup(Level.Trial)
        public void init() {
            calculator = new UbsCalculator();
        }

        @Setup(Level.Iteration)
        public void trialSetup() {
            batch = TEST_DATA_SUPPLIER.get();
        }

        public UbsCalculator calculator;
        public List<MarketUpdate> batch;
    }

    private static List<MarketUpdate> getRndBatch(int total) {
        return IntStream
                .range(0, total)
                .mapToObj(i -> getRndRecord())
                .collect(toList());
    }

    private static MarketUpdate getRndRecord() {
        return new ProviderMarketUpdate(
                getRndMarket(),
                getRndInstrument(),
                getRndState(),
                RND.nextDouble(),
                RND.nextDouble(),
                RND.nextDouble(),
                RND.nextDouble());
    }

    private static Market getRndMarket() {
        return Market.values()[RND.nextInt(TOTAL_AVAILABLE_MARKETS)];
    }

    private static Instrument getRndInstrument() {
        return Instrument.values()[RND.nextInt(TOTAL_AVAILABLE_INSTRUMENTS)];
    }

    private static State getRndState() {
        return RND.nextInt(3) < 2 ? FIRM : INDICATIVE;
    }


    private static final int TOTAL_AVAILABLE_MARKETS = Market.values().length;
    private static final int TOTAL_AVAILABLE_INSTRUMENTS = Instrument.values().length;
    private static final Random RND = new Random(currentTimeMillis());

    private static final int TEST_DATA_COUNTER = 1;
    private static int TEST_DATA_VARIATIONS = 50;

    private static int TEST_DATA_SUPPLIER_IDX = 0;

    private static final List<List<MarketUpdate>> TEST_DATA = IntStream
            .range(0, TEST_DATA_VARIATIONS)
            .mapToObj(i -> getRndBatch(TEST_DATA_COUNTER))
            .collect(Collectors.toList());

    private static final Supplier<List<MarketUpdate>> TEST_DATA_SUPPLIER = () -> {
        List<MarketUpdate> dataToReturn = TEST_DATA.get(TEST_DATA_SUPPLIER_IDX);
        TEST_DATA_SUPPLIER_IDX = (++TEST_DATA_SUPPLIER_IDX) % TEST_DATA_VARIATIONS;
        return dataToReturn;
    };
}