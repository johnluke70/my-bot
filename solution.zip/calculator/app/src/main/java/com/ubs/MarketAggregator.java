package com.ubs;

import com.ubs.core.*;

import static com.ubs.Utils.neq;
import static com.ubs.core.State.FIRM;
import static com.ubs.core.State.INDICATIVE;
import static java.util.Arrays.fill;

final class MarketAggregator {

    MarketAggregator(Instrument instrument) {

        vawpUpdate = new VwapPriceUpdate(instrument);
        currentState = FIRM;

        marketIndicator = new State[NUMBER_OF_MARKETS];
        fill(marketIndicator, FIRM);

        bidStats = new double[2][NUMBER_OF_MARKETS];
        init(bidStats, 2, NUMBER_OF_MARKETS);
        offerStats = new double[2][NUMBER_OF_MARKETS];
        init(offerStats, 2, NUMBER_OF_MARKETS);
    }

    private final VwapPriceUpdate vawpUpdate;

    private State currentState;
    private final State[] marketIndicator;

    private final double[][] bidStats;
    private final double[][] offerStats;

    TwoWayPrice merge(MarketUpdate marketUpdate) {

        final int marketIndex = marketUpdate.getMarket().marketIndex;
        final TwoWayPrice latestPriceUpdate = marketUpdate.getTwoWayPrice();

        computeState(marketIndex, latestPriceUpdate);
        computeVwap(marketIndex, latestPriceUpdate);

        return vawpUpdate;
    }

    private void computeVwap(int marketIndex, TwoWayPrice latestPriceUpdate) {

        if (neq(bidStats[AMOUNT][marketIndex], latestPriceUpdate.getBidAmount()) ||
                neq(bidStats[PRICE][marketIndex], latestPriceUpdate.getBidPrice())) {

            bidStats[AMOUNT][marketIndex] = latestPriceUpdate.getBidAmount();
            bidStats[PRICE][marketIndex] = latestPriceUpdate.getBidPrice();

            double partialProduct = 0.0, sum = 0.0;
            for (int i = 0; i < NUMBER_OF_MARKETS; ++i) {
                partialProduct += bidStats[PRICE][i] * bidStats[AMOUNT][i];
                sum += bidStats[AMOUNT][i];
            }

            vawpUpdate.setBidPrice(neq(sum, 0.0) ? partialProduct / sum : 0.0);
            vawpUpdate.setBidAmount(sum);
        }

        if (neq(offerStats[AMOUNT][marketIndex], latestPriceUpdate.getOfferAmount()) ||
                neq(offerStats[PRICE][marketIndex], latestPriceUpdate.getOfferPrice())) {

            offerStats[AMOUNT][marketIndex] = latestPriceUpdate.getOfferAmount();
            offerStats[PRICE][marketIndex] = latestPriceUpdate.getOfferPrice();

            double partialProduct = 0.0, sum = 0.0;
            for (int i = 0; i < NUMBER_OF_MARKETS; ++i) {
                partialProduct += offerStats[PRICE][i] * offerStats[AMOUNT][i];
                sum += offerStats[AMOUNT][i];
            }
            vawpUpdate.setOfferPrice(neq(sum, 0.0) ? partialProduct / sum : 0.0);
            vawpUpdate.setOfferAmount(sum);
        }
    }

    private void computeState(int marketIndex, TwoWayPrice twoWayPrice) {
        if (twoWayPrice.getState() == INDICATIVE) {
            marketIndicator[marketIndex] = INDICATIVE;
            if (currentState != INDICATIVE) {
                currentState = INDICATIVE;
            }
        } else {
            if (currentState == INDICATIVE) {
                marketIndicator[marketIndex] = FIRM;

                int i = 0;
                for(; i < NUMBER_OF_MARKETS; ++i) {
                    if (marketIndicator[i] != FIRM) break;
                }
                currentState = (i < NUMBER_OF_MARKETS) ? INDICATIVE : FIRM;
            }
        }
        vawpUpdate.setState(currentState);
    }

    private static void init(double[][] arr, int iLimit, int jLimit) {
        for (int i = 0; i < iLimit; ++i) {
            for (int j = 0; j < jLimit; ++j) {
                arr[i][j] = 0.0;
            }
        }
    }

    private static final int AMOUNT = 0;
    private static final int PRICE = 1;
    private static final int NUMBER_OF_MARKETS = Market.values().length;
}
